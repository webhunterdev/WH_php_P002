<?php
$servername = "localhost";
$username = "username";
$password = "password";

// Create connection
$conn = mysqli_connect('localhost', 'root');

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";

mysqli_select_db($conn, 'youtubeuserdeta');

$user =$_POST ['user'];
$email =$_POST ['email'];
$mobile =$_POST ['mobile'];
$comment =$_POST ['comment'];


$query = "insert into userinfodata (user, email, mobile, comment) 
VALUES ('$user','$email','$mobile','$comment')";

mysqli_query($conn,$query );

header('loaction:index.php');

?>