<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@100;200&display=swap" rel="stylesheet">
</head>

<body class="bg-secondary text-white">

    <div class="container">
        <!-- navbar start -->
<?php 
include 'menu.php' ?>
        <!-- navbar end -->
        <div class="jumbotron text-dark font-weight-bolder">
            <h1>Bootstrap Tutorial</h1>
            <p>Bootstrap is the most popular HTML, CSS...</p>
        </div>


        <!-- about us  start-->

        <section class=" my-5 py-5">
            <div>
                <h2 class="text-center mb-5">About Us</h2>
            </div>
            <div class="container">

                <div class="row">
                    <div class="col-lg-6 col-md-6 col-md-12">
                        <img src="img/la.jpg" class="img-fluid" alt="" srcset="">
                    </div>
                    <div class="col-lg-6 col-md-6 col-md-12 text-center">
                        <h2 class="mt-5"> I am a technical person</h2>
                        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Itaque quibusdam ratione, cum
                            maiores modi explicabo minima ut velit fugit dolores? Et provident deserunt aspernatur sit
                            sint nulla, cupiditate deleniti natus!</p>
                        <a href="about.php" target="_blank"><button type="button"
                                class="btn btn-primary font-weight-bolder">Read More</button></a>

                    </div>
                </div>
            </div>
        </section>
        <!-- about us  end-->


    </div>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>